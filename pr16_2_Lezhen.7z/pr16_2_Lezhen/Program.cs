﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr16_2_Lezhen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] nums = { 1.1, 2.2, 3.3, 1.1, 2.2, 1.1 };

            var groupnums = nums.GroupBy(n => n).Select(g => new { Number = g.Key, Count = g.Count() });

            foreach (var i in groupnums)
            {
                Console.WriteLine($"{i.Number} Повторы: {i.Count}");
            }

            Console.ReadKey();
        }
    }
}
