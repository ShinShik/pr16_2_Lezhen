﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr16_2_Lezhen
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Введите количество элементов массива");
            int n = Convert.ToInt32(Console.ReadLine());
            double q = 1.1;
            double[] num = new double[n];

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Введите {i+1} значение");
                string s = Console.ReadLine();
                if (double.TryParse(s, out q))
                {
                    num[i] = q;
                }
                else
                {
                    Console.WriteLine("Неправильный ввод, попробуйте снова");
                    i--;
                }
            }

            var GroupNum = num.GroupBy(a => a).Select(g => new { Number = g.Key, Count = g.Count() });

            foreach (var i in GroupNum)
            {
                Console.WriteLine($"{i.Number} Повторы: {i.Count}");
            }

            Console.ReadKey();
        }
    }
}
